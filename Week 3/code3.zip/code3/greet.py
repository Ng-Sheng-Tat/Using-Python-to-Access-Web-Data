name = input('Enter your name: ')
print('Hello', name)
